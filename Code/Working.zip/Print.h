#ifndef PRINT_H
#define PRINT_H

#include <unordered_map>
#include "Tree.h"

void print(std::unordered_map<int, struct Tree *> &hash, int key);


#endif